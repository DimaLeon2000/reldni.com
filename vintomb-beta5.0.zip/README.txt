NAME - Vinnie's Tomb Chapter One - The Road to Vinnie's Tomb (For Lack of A Better Title)
DEVELOPER - Reldni Productions
VERSION - BETA 5.0
RELEASE DATE - 12-03-1997

Obtained by Dmitri Leont'ev from the Game Pack in the Palit Microsystems DAYTONA Plug and Play CD with its ID: CD#027.

"Be sure to visit this Vinnie's Tomb page regularly. We will be updating it with news and features. March 12th 1997 was the day "Vinnie's Tomb Chapter One - On The Road To Vinnie's Tomb (for lack of a better title) Beta 5.0" was released to the stunned and horrified public. Never before had the world witnessed this phenomenal success in gaming history. Skeptics and critics were mesmerized too. The plethora of excitement reached the inner most sanctums and dungeons. People paused in the floating chaos to be humbled by this great game. Stock market analysts soon believed that "Vinnie's Tomb" held a mysterious coded key to financial prosperity. The game became a rallying point for a group of fanatics who had one too many. As the triumphant bugle calls tweeted throughout the land "Vinnie's Tomb" reigned supreme shining atop of the highest peak."

https://web.archive.org/web/19970709000642/http://www.skylinc.net/~reldni/vinnie/vintomb.html