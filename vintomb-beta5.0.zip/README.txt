NAME - Vinnie's Tomb Chapter One - The Road to Vinnie's Tomb (For Lack of A Better Title)
DEVELOPER - Reldni Productions
VERSION - BETA 5.0
RELEASE DATE - 09-03-1997

Obtained by Dmitri Leont'ev from the Game Pack in the Palit Microsystems DAYTONA Plug and Play CD with its ID: CD#027.